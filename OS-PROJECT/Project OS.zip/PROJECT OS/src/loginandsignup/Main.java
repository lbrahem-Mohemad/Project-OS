
package loginandsignup;

public class Main {


    public static void main(String[] args) {

        OpeatingSystems OS = new OpeatingSystems();
        OS.setVisible(true);
        OS.pack();
        OS.setLocationRelativeTo(null); 
    }
    
}
